@extends('adminlte::page')

@section('title', 'Inventario')

@section('content_header')
    <h1>Agregar Nueva producto</h1>
@stop

@section('content')
    <div class="container-fluid">
        <form action="{{url('inventario')}}" method="post">
            @csrf()
            <div class="card">

                <div class="card-body col-3">
                    {{dd($categs[1])}}

                        <div ><select class="form-control input-sm" >
                            @foreach ( $categs[1] as $categoria )

                            <option value="10">{{ $categoria->DESC_CATEGORIA }}</option>
                            @endforeach


                            </select></div>
                </div>

                <div class="card-body col-3">


                    <div ><select class="form-control input-sm"  >
                          <option value="10">Medicamentos</option>
                          <option value="25">Utencilios</option>
                          <option value="50">Aseo</option>
                          <option value="100">Equipo de oficina</option>
                        </select></div>
            </div>

                     <div class="card-body col-3">
                    <div class="form-group">
                        <label class="text-danger"> *ingrese el producto</label>
                        <input type="text" class="form-control" name="PV_DESC_CATEGORIA" pattern="^[\p{L} \.'\-]+$"
                        title="Solo puede ingresar letras" maxlength="50" required>
                    </div>
                </div>
                <div class="card-footer">
                    <input class="btn btn-primary" type="submit" value="Guardar" />
                    <a class="btn btn-dark" href="{{url('inventario')}}">Regresar</a>
                </div>
            </div>
        </form>
    </div>
@stop

@section('css')
@stop

@section('js')
@stop
