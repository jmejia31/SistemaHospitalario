<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\inventario\CategoriaController;
use App\Http\Controllers\Inventarios\InventariosController;

Route::get('/', function () {
    return view('welcome');
});



Route::resource("/inventario", CategoriaController::class);

//CitasMedicas

//Compras

//ExpedientesMedicos

//Inventarios
Route::resource("/inventario", InventariosController::class);
//NotasAudios

//Personas

//ReportesEstadisticas

//Ventas

//Seguridad

//Empresa
