<?php $__env->startSection('title', 'Inventario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Nueva producto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(url('inventario')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card">

                <div class="card-body col-3">
                    <?php echo e(dd($categs[1])); ?>


                        <div ><select class="form-control input-sm" >
                            <?php $__currentLoopData = $categs[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="10"><?php echo e($categoria->DESC_CATEGORIA); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select></div>
                </div>

                <div class="card-body col-3">


                    <div ><select class="form-control input-sm"  >
                          <option value="10">Medicamentos</option>
                          <option value="25">Utencilios</option>
                          <option value="50">Aseo</option>
                          <option value="100">Equipo de oficina</option>
                        </select></div>
            </div>

                     <div class="card-body col-3">
                    <div class="form-group">
                        <label class="text-danger"> *ingrese el producto</label>
                        <input type="text" class="form-control" name="PV_DESC_CATEGORIA" pattern="^[\p{L} \.'\-]+$"
                        title="Solo puede ingresar letras" maxlength="50" required>
                    </div>
                </div>
                <div class="card-footer">
                    <input class="btn btn-primary" type="submit" value="Guardar" />
                    <a class="btn btn-dark" href="<?php echo e(url('inventario')); ?>">Regresar</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALEX MORALES\Desktop\proyecto shh\SHH\resources\views/Inventarios/crear.blade.php ENDPATH**/ ?>