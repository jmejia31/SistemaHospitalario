<?php $__env->startSection('title', 'Inventario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Inventario</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <a class="btn btn-success" href="<?php echo e(url('inventario/create')); ?>">Crear</a>
            </div>
            <div class="card-body">
                <table id="registros" class="table table-bordered table-hover dataTable dtr-inline">
                   
                    <tr>
                        <th>#</th>
                        <th>Nombre de la categoria</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    <?php $__currentLoopData = $inventario[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resulproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($resulproducto->COD_PRODUCTO); ?></td>
                            <td><?php echo e($resulproducto->COD_CATEG); ?></td>
                            <td><?php echo e($resulproducto->COD_PROVEEDOR); ?></td>
                            <td><?php echo e($resulproducto->DESCRIPCION_PRODUCTO); ?></td>
                            <td><?php echo e($resulproducto->MARCA); ?></td>
                            <td><?php echo e($resulproducto->CONTENIDO_NETO); ?></td>
                            <td><?php echo e($resulproducto->TIPO_DE_EMPAQUE); ?></td>
                            <td><?php echo e($resulproducto->CODIGO_DE_BARRAS); ?></td>
                            <td><?php echo e($resulproducto->CANTIDAD_UNITARIA); ?></td>
                            <td><?php echo e($resulproducto->PRECIO_UNITARIO); ?></td>
                            <td><?php echo e($resulproducto->PRECIO_VENTA); ?></td>
                            <td><?php echo e($resulproducto->COSTO_TOTAL); ?></td>
                            <td><?php echo e($resulproducto->ISV); ?></td>
                            <td><?php echo e($resulproducto->ESTADO); ?></td>
                            <td><?php echo e($resulproducto->IMAGEN); ?></td>
                            <td>
                                <a class="btn btn-warning"
                                    href="<?php echo e(url('inventario/' . $resulproducto->COD_PRODUCTO . '/edit')); ?>">Editar</a>
                            </td>
                            <td>
                                <a class="btn btn-primary"
                                    href="<?php echo e(url('inventario/' . $resulproducto->COD_PRODUCTO)); ?>">Consultar</a>
                            </td>
                            <td>
                                <form method="post" action="<?php echo e(url('inventario', $resulproducto->COD_PRODUCTO)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input class="btn btn-danger" type="submit" value="Eliminar" />
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $("#registros").DataTable({
                "language": {
                    "sSearch": "Buscar:",
                    "sEmptyTable": "No hay datos disponibles",
                    "sZeroRecords": "No se han encontrado resultados",
                    "sInfo": "Mostrando registros del _START_ al _END_ de un total _TOTAL_",
                    "SInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0",
                    "sInfoFiltered": "(filtrando de un total de _MAX_ registrados)",
                    "oPaginate": {
                        "sFirst": "Primero",
                        "sLast": "Último",

                        "sNext": "Siguiente",
                        "sPrevious": "Anterior"
                    },

                    "sLoadingRecords": "Cargando...",
                    "sLengthMenu": "Mostrar _MENU_ registros"
                },
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALEX MORALES\Desktop\proyecto shh\SHH\resources\views/Inventarios/inicio.blade.php ENDPATH**/ ?>