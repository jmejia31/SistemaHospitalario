<?php $__env->startSection('title', 'Categorias'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Categoria</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php $__currentLoopData = $categorias[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(url('categorias', $categoria->COD_CATEG)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label class=""> Codigo de la categoria</label>
                            <input type="text" class="form-control" value="<?php echo e($categoria->COD_CATEG); ?>"
                                name="PI_COD_CATEGORIA" disabled required>
                        </div>

                        <div class="form-group">
                            <label class="text-danger"> * Nombre de la categoria</label>
                            <input type="text" class="form-control" value="<?php echo e($categoria->DESC_CATEGORIA); ?>"
                                name="PV_DESC_CATEGORIA" pattern="^[\p{L} \.'\-]+$" title="Solo puede ingresar letras"
                                maxlength="50" required>
                        </div>
                </div>
                <div class="card-footer">
                    <input class="btn btn-primary" type="submit" value="Actualizar" />
                    <a class="btn btn-dark" href="<?php echo e(url('categorias')); ?>">Regresar</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALEX MORALES\Desktop\proyecto shh\SHH\resources\views/inventario/categorias/editar.blade.php ENDPATH**/ ?>