<?php $__env->startSection('title', 'Categorias'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Agregar Nueva Categoria</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(url('categorias')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label class="text-danger"> * Nombre de la categoria</label>
                        <input type="text" class="form-control" name="PV_DESC_CATEGORIA" pattern="^[\p{L} \.'\-]+$"
                        title="Solo puede ingresar letras" maxlength="50" required>
                    </div>
                </div>
                <div class="card-footer">
                    <input class="btn btn-primary" type="submit" value="Guardar" />
                    <a class="btn btn-dark" href="<?php echo e(url('categorias')); ?>">Regresar</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ALEX MORALES\Desktop\proyecto shh\SHH\resources\views/inventario/categorias/crear.blade.php ENDPATH**/ ?>